import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
    return (
        <header className="flex justify-between py-7 px-20">
            <h1 className="font-semibold text-4xl text-black">OptiTrade</h1>
            <nav className="flex gap-16">
                <Link to="/" className="font-montserrat text-2xl font-semibold text-black no-underline">Home</Link>
                <Link to="/trading" className="font-montserrat text-2xl font-semibold text-black no-underline">Trading</Link>
                <Link to="/market" className="font-montserrat text-2xl font-semibold text-black no-underline">Market</Link>
                <Link to="/learn" className="font-montserrat text-2xl font-semibold text-black no-underline">Learn</Link>
                <Link to="/about" className="font-montserrat text-2xl font-semibold text-black no-underline">About</Link>
            </nav>
            <div className="flex gap-3">
                <Link to="/login">
                    <button className="w-32 h-11 rounded-full border border-black font-semibold text-lg bg-white">Log in</button>
                </Link>
                <Link to="/signup">
                    <button className="w-32 h-11 rounded-full border border-white font-semibold text-lg bg-black text-white">Sign up</button>
                </Link>
            </div>
        </header>
    );
};

export default Header;
